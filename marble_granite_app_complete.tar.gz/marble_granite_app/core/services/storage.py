import os
import shutil
import json
from datetime import datetime
try:
    from plyer import storagepath
    PLYER_AVAILABLE = True
except ImportError:
    PLYER_AVAILABLE = False

class StorageService:
    def __init__(self):
        self.app_dir = self._get_app_directory()
        self.attachments_dir = os.path.join(self.app_dir, "attachments")
        self.exports_dir = os.path.join(self.app_dir, "exports")
        self.pdfs_dir = os.path.join(self.app_dir, "pdfs")
        
        # Create directories if they don't exist
        for directory in [self.app_dir, self.attachments_dir, self.exports_dir, self.pdfs_dir]:
            os.makedirs(directory, exist_ok=True)
    
    def _get_app_directory(self):
        """Get the application's data directory."""
        if PLYER_AVAILABLE:
            try:
                # Try to get the app's private storage directory
                return os.path.join(storagepath.get_documents_dir(), "MarbleGraniteApp")
            except:
                pass
        
        # Fallback to current directory
        return os.path.join(os.getcwd(), "app_data")
    
    def save_attachment(self, source_path, filename):
        """Save an attachment file and return the saved path."""
        try:
            # Generate unique filename if needed
            base_name, ext = os.path.splitext(filename)
            counter = 1
            final_filename = filename
            
            while os.path.exists(os.path.join(self.attachments_dir, final_filename)):
                final_filename = f"{base_name}_{counter}{ext}"
                counter += 1
            
            destination_path = os.path.join(self.attachments_dir, final_filename)
            shutil.copy2(source_path, destination_path)
            
            return destination_path
            
        except Exception as e:
            print(f"Error saving attachment: {e}")
            return None
    
    def save_pdf(self, pdf_content, filename):
        """Save a PDF file and return the saved path."""
        try:
            # Ensure filename has .pdf extension
            if not filename.endswith('.pdf'):
                filename += '.pdf'
            
            pdf_path = os.path.join(self.pdfs_dir, filename)
            
            # If pdf_content is bytes, write directly
            if isinstance(pdf_content, bytes):
                with open(pdf_path, 'wb') as f:
                    f.write(pdf_content)
            else:
                # If it's a file path, copy it
                shutil.copy2(pdf_content, pdf_path)
            
            return pdf_path
            
        except Exception as e:
            print(f"Error saving PDF: {e}")
            return None
    
    def export_database(self):
        """Export database and attachments to a backup file."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            export_filename = f"backup_{timestamp}.zip"
            export_path = os.path.join(self.exports_dir, export_filename)
            
            # Create a zip file with database and attachments
            import zipfile
            
            with zipfile.ZipFile(export_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # Add database file
                db_path = "marble_granite.db"
                if os.path.exists(db_path):
                    zipf.write(db_path, "database.db")
                
                # Add attachments directory
                if os.path.exists(self.attachments_dir):
                    for root, dirs, files in os.walk(self.attachments_dir):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, self.app_dir)
                            zipf.write(file_path, arcname)
                
                # Add metadata
                metadata = {
                    "export_date": datetime.now().isoformat(),
                    "app_version": "1.0.0",
                    "database_version": 1
                }
                zipf.writestr("metadata.json", json.dumps(metadata, indent=2))
            
            return export_path
            
        except Exception as e:
            print(f"Error exporting database: {e}")
            return None
    
    def import_database(self, backup_path):
        """Import database and attachments from a backup file."""
        try:
            import zipfile
            
            with zipfile.ZipFile(backup_path, 'r') as zipf:
                # Extract database
                if "database.db" in zipf.namelist():
                    zipf.extract("database.db", ".")
                    os.rename("database.db", "marble_granite.db")
                
                # Extract attachments
                for file_info in zipf.filelist:
                    if file_info.filename.startswith("attachments/"):
                        zipf.extract(file_info, self.app_dir)
                
                # Read metadata
                if "metadata.json" in zipf.namelist():
                    metadata_content = zipf.read("metadata.json")
                    metadata = json.loads(metadata_content.decode('utf-8'))
                    print(f"Imported backup from {metadata.get('export_date')}")
            
            return True
            
        except Exception as e:
            print(f"Error importing database: {e}")
            return False
    
    def get_pdf_path(self, filename):
        """Get the full path for a PDF file."""
        if not filename.endswith('.pdf'):
            filename += '.pdf'
        return os.path.join(self.pdfs_dir, filename)
    
    def list_pdfs(self):
        """List all PDF files in the PDFs directory."""
        try:
            pdf_files = []
            for filename in os.listdir(self.pdfs_dir):
                if filename.endswith('.pdf'):
                    file_path = os.path.join(self.pdfs_dir, filename)
                    file_stat = os.stat(file_path)
                    pdf_files.append({
                        'filename': filename,
                        'path': file_path,
                        'size': file_stat.st_size,
                        'modified': datetime.fromtimestamp(file_stat.st_mtime)
                    })
            return pdf_files
        except Exception as e:
            print(f"Error listing PDFs: {e}")
            return []

# Global storage service instance
storage_service = StorageService()

