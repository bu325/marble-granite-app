def area_m2(length_m, width_m, pieces):
    """Calculates area in m2, thickness is not included."""
    if length_m is None or width_m is None or pieces is None:
        return 0.0
    if length_m < 0 or width_m < 0 or pieces < 0:
        raise ValueError("Dimensions and pieces cannot be negative.")
    return length_m * width_m * pieces

def purchase_cost(items):
    """Calculates total purchase cost from a list of invoice items."""
    total_cost = 0.0
    for item in items:
        if item.area_m2 < 0 or item.buy_price_m2 < 0:
            raise ValueError("Area or buy price cannot be negative.")
        total_cost += item.area_m2 * item.buy_price_m2
    return total_cost

def sell_price(items):
    """Calculates total selling price from a list of invoice items."""
    total_sell_price = 0.0
    for item in items:
        if item.area_m2 < 0 or item.sell_price_m2 < 0:
            raise ValueError("Area or sell price cannot be negative.")
        total_sell_price += item.area_m2 * item.sell_price_m2
    return total_sell_price

def pre_discount_total(sell_price_materials, delivery_fee_billed, install_fee_billed):
    """Calculates total before discount, including material sell price, delivery and installation fees."""
    if sell_price_materials < 0 or delivery_fee_billed < 0 or install_fee_billed < 0:
        raise ValueError("Prices and fees cannot be negative.")
    return sell_price_materials + delivery_fee_billed + install_fee_billed

def discount(amount, rate):
    """Calculates discount amount."""
    if amount < 0 or rate < 0:
        raise ValueError("Amount or rate cannot be negative.")
    return amount * (rate / 100.0)

def taxable_base(pre_discount_total_amount, discount_amount):
    """Calculates the taxable base after discount."""
    if pre_discount_total_amount < 0 or discount_amount < 0:
        raise ValueError("Amounts cannot be negative.")
    base = pre_discount_total_amount - discount_amount
    if base < 0:
        raise ValueError("Taxable base cannot be negative.")
    return base

def tax_amount(base, tax_rate):
    """Calculates tax amount."""
    if base < 0 or tax_rate < 0:
        raise ValueError("Base or tax rate cannot be negative.")
    return base * (tax_rate / 100.0)

def final_total(base, tax_amount_val):
    """Calculates final total including tax."""
    if base < 0 or tax_amount_val < 0:
        raise ValueError("Base or tax amount cannot be negative.")
    return base + tax_amount_val

def profit_margin(sell_price_materials, delivery_fee_billed, install_fee_billed, purchase_cost_materials, direct_extra_costs=0.0):
    """Calculates profit margin for an invoice."""
    if any(val < 0 for val in [sell_price_materials, delivery_fee_billed, install_fee_billed, purchase_cost_materials, direct_extra_costs]):
        raise ValueError("All input values for profit margin must be non-negative.")
    return (sell_price_materials + delivery_fee_billed + install_fee_billed) - purchase_cost_materials - direct_extra_costs

def net_profit(profit_margin_val, workers_wages, extra_expenses):
    """Calculates net profit after deducting wages and other expenses."""
    if any(val < 0 for val in [profit_margin_val, workers_wages, extra_expenses]):
        raise ValueError("All input values for net profit must be non-negative.")
    return profit_margin_val - workers_wages - extra_expenses



