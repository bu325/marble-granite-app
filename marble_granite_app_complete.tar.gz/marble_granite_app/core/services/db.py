from core.models.base import db, BaseModel
from core.models.inventory import Material, StockMove
from core.models.clients import Client
from core.models.workers import Worker, Attendance
from core.models.invoices import Invoice, InvoiceItem
from core.models.expenses import Expense

def initialize_db():
    db.connect()
    db.create_tables([
        Material, StockMove, Client, Worker, Attendance, Invoice, InvoiceItem, Expense
    ])
    db.close()



