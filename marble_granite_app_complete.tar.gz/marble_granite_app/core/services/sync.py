import requests
import json
from datetime import datetime
from core.models.base import db
from core.models.inventory import Material, StockMove
from core.models.clients import Client
from core.models.workers import Worker, Attendance
from core.models.invoices import Invoice, InvoiceItem
from core.models.expenses import Expense

class SyncService:
    def __init__(self, base_url="https://api.example.com", api_key=""):
        self.base_url = base_url
        self.api_key = api_key
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
    
    def get_last_sync_time(self):
        """Get the last synchronization timestamp from local storage."""
        # TODO: Implement storage of last sync time
        return datetime(2024, 1, 1)  # Default fallback
    
    def set_last_sync_time(self, timestamp):
        """Set the last synchronization timestamp in local storage."""
        # TODO: Implement storage of last sync time
        pass
    
    def pull_changes(self):
        """Pull changes from remote server since last sync."""
        last_sync = self.get_last_sync_time()
        
        try:
            # Pull materials
            response = requests.get(
                f"{self.base_url}/materials",
                params={"updated_since": last_sync.isoformat()},
                headers=self.headers,
                timeout=30
            )
            if response.status_code == 200:
                materials = response.json()
                self._update_local_materials(materials)
            
            # Pull clients
            response = requests.get(
                f"{self.base_url}/clients",
                params={"updated_since": last_sync.isoformat()},
                headers=self.headers,
                timeout=30
            )
            if response.status_code == 200:
                clients = response.json()
                self._update_local_clients(clients)
            
            # Pull other entities...
            
            self.set_last_sync_time(datetime.now())
            return True, "تم سحب التحديثات بنجاح"
            
        except requests.RequestException as e:
            return False, f"خطأ في الاتصال: {str(e)}"
        except Exception as e:
            return False, f"خطأ غير متوقع: {str(e)}"
    
    def push_changes(self):
        """Push local changes to remote server."""
        last_sync = self.get_last_sync_time()
        
        try:
            # Push materials
            materials = Material.select().where(Material.updated_at > last_sync)
            for material in materials:
                data = {
                    "id": material.id,
                    "name": material.name,
                    "type": material.type,
                    "buy_price_m2": material.buy_price_m2,
                    "sell_price_m2": material.sell_price_m2,
                    "qty_value": material.qty_value,
                    "updated_at": material.updated_at.isoformat(),
                    "version": material.version
                }
                
                if material.remote_id:
                    # Update existing
                    response = requests.put(
                        f"{self.base_url}/materials/{material.remote_id}",
                        json=data,
                        headers=self.headers,
                        timeout=30
                    )
                else:
                    # Create new
                    response = requests.post(
                        f"{self.base_url}/materials",
                        json=data,
                        headers=self.headers,
                        timeout=30
                    )
                    if response.status_code == 201:
                        remote_data = response.json()
                        material.remote_id = remote_data.get("id")
                        material.save()
            
            # Push other entities...
            
            return True, "تم رفع التحديثات بنجاح"
            
        except requests.RequestException as e:
            return False, f"خطأ في الاتصال: {str(e)}"
        except Exception as e:
            return False, f"خطأ غير متوقع: {str(e)}"
    
    def sync_all(self):
        """Perform full synchronization (pull then push)."""
        # First pull changes from server
        pull_success, pull_message = self.pull_changes()
        if not pull_success:
            return False, pull_message
        
        # Then push local changes
        push_success, push_message = self.push_changes()
        if not push_success:
            return False, push_message
        
        return True, "تمت المزامنة بنجاح"
    
    def _update_local_materials(self, materials_data):
        """Update local materials with data from server."""
        for material_data in materials_data:
            try:
                # Check if material exists locally
                material = Material.get_or_none(Material.remote_id == material_data["id"])
                
                if material:
                    # Check for conflicts (Last Writer Wins strategy)
                    if material.version < material_data.get("version", 0):
                        # Update local material
                        material.name = material_data["name"]
                        material.type = material_data["type"]
                        material.buy_price_m2 = material_data["buy_price_m2"]
                        material.sell_price_m2 = material_data["sell_price_m2"]
                        material.qty_value = material_data["qty_value"]
                        material.version = material_data["version"]
                        material.save()
                else:
                    # Create new local material
                    Material.create(
                        remote_id=material_data["id"],
                        name=material_data["name"],
                        type=material_data["type"],
                        buy_price_m2=material_data["buy_price_m2"],
                        sell_price_m2=material_data["sell_price_m2"],
                        qty_value=material_data["qty_value"],
                        version=material_data["version"]
                    )
            except Exception as e:
                print(f"Error updating material {material_data.get('id')}: {e}")
    
    def _update_local_clients(self, clients_data):
        """Update local clients with data from server."""
        for client_data in clients_data:
            try:
                # Check if client exists locally
                client = Client.get_or_none(Client.remote_id == client_data["id"])
                
                if client:
                    # Check for conflicts (Last Writer Wins strategy)
                    if client.version < client_data.get("version", 0):
                        # Update local client
                        client.name = client_data["name"]
                        client.phone = client_data.get("phone")
                        client.address = client_data.get("address")
                        client.version = client_data["version"]
                        client.save()
                else:
                    # Create new local client
                    Client.create(
                        remote_id=client_data["id"],
                        name=client_data["name"],
                        phone=client_data.get("phone"),
                        address=client_data.get("address"),
                        version=client_data["version"]
                    )
            except Exception as e:
                print(f"Error updating client {client_data.get('id')}: {e}")

# Global sync service instance
sync_service = SyncService()

