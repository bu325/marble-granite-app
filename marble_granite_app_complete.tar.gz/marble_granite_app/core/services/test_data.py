from datetime import datetime, date, timedelta
from core.models.base import db
from core.models.inventory import Material, StockMove
from core.models.clients import Client
from core.models.workers import Worker, Attendance
from core.models.invoices import Invoice, InvoiceItem
from core.models.expenses import Expense
from core.services.calc import area_m2

def create_test_data():
    """Create comprehensive test data for the application."""
    
    # Connect to database and create tables
    from core.services.db import initialize_db
    initialize_db()
    
    db.connect()
    
    print("Creating test data...")
    
    # Create suppliers and materials
    materials_data = [
        {
            "name": "رخام كرارة أبيض",
            "type": "رخام",
            "length_m": 3.0,
            "width_m": 2.0,
            "thickness_mm": 20.0,
            "buy_price_m2": 200.0,
            "sell_price_m2": 280.0,
            "qty_unit": "slab",
            "qty_value": 15.0,
            "supplier": "شركة الرخام الإيطالي",
            "low_stock_threshold": 5.0
        },
        {
            "name": "جرانيت أسود زيمبابوي",
            "type": "جرانيت",
            "length_m": 2.5,
            "width_m": 1.5,
            "thickness_mm": 30.0,
            "buy_price_m2": 150.0,
            "sell_price_m2": 220.0,
            "qty_unit": "slab",
            "qty_value": 8.0,
            "supplier": "مؤسسة الجرانيت الأفريقي",
            "low_stock_threshold": 3.0
        },
        {
            "name": "رخام أخضر هندي",
            "type": "رخام",
            "length_m": 2.8,
            "width_m": 1.8,
            "thickness_mm": 25.0,
            "buy_price_m2": 180.0,
            "sell_price_m2": 260.0,
            "qty_unit": "slab",
            "qty_value": 12.0,
            "supplier": "شركة الرخام الهندي",
            "low_stock_threshold": 4.0
        },
        {
            "name": "جرانيت رمادي محلي",
            "type": "جرانيت",
            "length_m": 3.2,
            "width_m": 2.2,
            "thickness_mm": 20.0,
            "buy_price_m2": 120.0,
            "sell_price_m2": 180.0,
            "qty_unit": "slab",
            "qty_value": 20.0,
            "supplier": "مقالع المغرب",
            "low_stock_threshold": 8.0
        },
        {
            "name": "رخام أبيض محلي",
            "type": "رخام",
            "length_m": 2.0,
            "width_m": 1.0,
            "thickness_mm": 15.0,
            "buy_price_m2": 100.0,
            "sell_price_m2": 150.0,
            "qty_unit": "m2",
            "qty_value": 45.5,
            "supplier": "مقالع الأطلس",
            "low_stock_threshold": 20.0
        },
        {
            "name": "جرانيت أحمر برازيلي",
            "type": "جرانيت",
            "length_m": 3.0,
            "width_m": 1.8,
            "thickness_mm": 30.0,
            "buy_price_m2": 250.0,
            "sell_price_m2": 350.0,
            "qty_unit": "slab",
            "qty_value": 6.0,
            "supplier": "شركة الجرانيت البرازيلي",
            "low_stock_threshold": 2.0
        },
        {
            "name": "رخام بيج تركي",
            "type": "رخام",
            "length_m": 2.4,
            "width_m": 1.6,
            "thickness_mm": 20.0,
            "buy_price_m2": 160.0,
            "sell_price_m2": 230.0,
            "qty_unit": "slab",
            "qty_value": 10.0,
            "supplier": "شركة الرخام التركي",
            "low_stock_threshold": 3.0
        },
        {
            "name": "جرانيت أزرق نرويجي",
            "type": "جرانيت",
            "length_m": 2.6,
            "width_m": 1.4,
            "thickness_mm": 25.0,
            "buy_price_m2": 300.0,
            "sell_price_m2": 420.0,
            "qty_unit": "slab",
            "qty_value": 4.0,
            "supplier": "شركة الجرانيت الاسكندنافي",
            "low_stock_threshold": 2.0
        },
        {
            "name": "رخام وردي برتغالي",
            "type": "رخام",
            "length_m": 2.2,
            "width_m": 1.2,
            "thickness_mm": 18.0,
            "buy_price_m2": 220.0,
            "sell_price_m2": 310.0,
            "qty_unit": "slab",
            "qty_value": 7.0,
            "supplier": "شركة الرخام الأوروبي",
            "low_stock_threshold": 2.0
        },
        {
            "name": "جرانيت ذهبي هندي",
            "type": "جرانيت",
            "length_m": 3.5,
            "width_m": 2.5,
            "thickness_mm": 30.0,
            "buy_price_m2": 280.0,
            "sell_price_m2": 380.0,
            "qty_unit": "slab",
            "qty_value": 5.0,
            "supplier": "شركة الرخام الهندي",
            "low_stock_threshold": 2.0
        }
    ]
    
    created_materials = []
    for material_data in materials_data:
        material = Material.create(**material_data)
        created_materials.append(material)
        print(f"Created material: {material.name}")
    
    # Create clients
    clients_data = [
        {
            "name": "أحمد محمد العلوي",
            "phone": "+212 600 123456",
            "address": "حي النهضة، شارع الحسن الثاني، الدار البيضاء",
            "notes": "عميل مميز، يفضل الرخام الإيطالي"
        },
        {
            "name": "فاطمة الزهراء بنعلي",
            "phone": "+212 661 789012",
            "address": "أكدال، شارع محمد الخامس، الرباط",
            "notes": "مشروع فيلا كبيرة، طلبات متكررة"
        },
        {
            "name": "يوسف الإدريسي",
            "phone": "+212 650 345678",
            "address": "المدينة القديمة، فاس",
            "notes": "يعمل في مجال البناء، عميل تاجر"
        },
        {
            "name": "خديجة المرابطي",
            "phone": "+212 670 456789",
            "address": "جليز، مراكش",
            "notes": "مشروع فندق، طلبات كبيرة"
        },
        {
            "name": "عبد الرحمن التازي",
            "phone": "+212 680 567890",
            "address": "حي السلام، تطوان",
            "notes": "عميل جديد، مشروع شقة"
        }
    ]
    
    created_clients = []
    for client_data in clients_data:
        client = Client.create(**client_data)
        created_clients.append(client)
        print(f"Created client: {client.name}")
    
    # Create workers
    workers_data = [
        {
            "name": "محمد الحداد",
            "phone": "+212 600 111222",
            "wage_type": "daily",
            "wage_rate": 200.0,
            "active_from": date(2024, 1, 1)
        },
        {
            "name": "عبد الله النجار",
            "phone": "+212 661 333444",
            "wage_type": "monthly",
            "wage_rate": 4500.0,
            "active_from": date(2024, 1, 1)
        },
        {
            "name": "حسن البناء",
            "phone": "+212 650 555666",
            "wage_type": "per_m2",
            "wage_rate": 25.0,
            "active_from": date(2024, 1, 1)
        },
        {
            "name": "سعيد المركب",
            "phone": "+212 670 777888",
            "wage_type": "daily",
            "wage_rate": 180.0,
            "active_from": date(2024, 1, 15)
        }
    ]
    
    created_workers = []
    for worker_data in workers_data:
        worker = Worker.create(**worker_data)
        created_workers.append(worker)
        print(f"Created worker: {worker.name}")
    
    # Create attendance records for the last 2 weeks
    start_date = date.today() - timedelta(days=14)
    for i in range(14):
        current_date = start_date + timedelta(days=i)
        
        for worker in created_workers:
            # Most workers present most days, some random absences
            import random
            present = random.random() > 0.1  # 90% attendance rate
            
            Attendance.create(
                worker=worker,
                date=current_date,
                present=present,
                note="حضور عادي" if present else "غياب"
            )
    
    print("Created attendance records for 2 weeks")
    
    # Create expenses
    expenses_data = [
        {
            "type": "إيجار المحل",
            "amount": 3500.0,
            "date": date(2024, 1, 1),
            "note": "إيجار شهر يناير"
        },
        {
            "type": "فاتورة الكهرباء",
            "amount": 450.0,
            "date": date(2024, 1, 5),
            "note": "استهلاك ديسمبر"
        },
        {
            "type": "صيانة المعدات",
            "amount": 800.0,
            "date": date(2024, 1, 10),
            "note": "صيانة آلة القطع"
        },
        {
            "type": "وقود النقل",
            "amount": 600.0,
            "date": date(2024, 1, 15),
            "note": "وقود شاحنة التوصيل"
        },
        {
            "type": "مواد التنظيف",
            "amount": 150.0,
            "date": date(2024, 1, 20),
            "note": "مواد تنظيف الرخام"
        }
    ]
    
    for expense_data in expenses_data:
        expense = Expense.create(**expense_data)
        print(f"Created expense: {expense.type} - {expense.amount}")
    
    # Create invoices with items
    invoices_data = [
        {
            "client": created_clients[0],
            "date": date(2024, 1, 15),
            "type": "both",
            "delivery_fee_billed": 200.0,
            "delivery_cost_actual": 150.0,
            "install_fee_billed": 500.0,
            "discount_rate": 5.0,
            "tax_rate": 20.0,
            "status": "posted",
            "reference": "INV-2024-001",
            "note": "مشروع مطبخ فيلا",
            "items": [
                {"material": created_materials[0], "pieces": 2.0, "length_m": 3.0, "width_m": 2.0},
                {"material": created_materials[1], "pieces": 1.0, "length_m": 2.5, "width_m": 1.5}
            ]
        },
        {
            "client": created_clients[1],
            "date": date(2024, 1, 18),
            "type": "sale",
            "delivery_fee_billed": 150.0,
            "delivery_cost_actual": 120.0,
            "install_fee_billed": 0.0,
            "discount_rate": 0.0,
            "tax_rate": 20.0,
            "status": "posted",
            "reference": "INV-2024-002",
            "note": "بيع فقط - العميل سيركب بنفسه",
            "items": [
                {"material": created_materials[2], "pieces": 3.0, "length_m": 2.8, "width_m": 1.8}
            ]
        },
        {
            "client": created_clients[2],
            "date": date(2024, 1, 20),
            "type": "install",
            "delivery_fee_billed": 0.0,
            "delivery_cost_actual": 0.0,
            "install_fee_billed": 800.0,
            "discount_rate": 0.0,
            "tax_rate": 20.0,
            "status": "posted",
            "reference": "INV-2024-003",
            "note": "تركيب فقط - المواد من مخزون العميل",
            "items": []
        },
        {
            "client": created_clients[3],
            "date": date(2024, 1, 22),
            "type": "both",
            "delivery_fee_billed": 300.0,
            "delivery_cost_actual": 250.0,
            "install_fee_billed": 1200.0,
            "discount_rate": 10.0,
            "tax_rate": 20.0,
            "status": "posted",
            "reference": "INV-2024-004",
            "note": "مشروع فندق - المرحلة الأولى",
            "items": [
                {"material": created_materials[3], "pieces": 4.0, "length_m": 3.2, "width_m": 2.2},
                {"material": created_materials[4], "pieces": 0.0, "length_m": 0.0, "width_m": 0.0, "area_override": 25.0},
                {"material": created_materials[5], "pieces": 1.0, "length_m": 3.0, "width_m": 1.8}
            ]
        },
        {
            "client": created_clients[4],
            "date": date(2024, 1, 25),
            "type": "both",
            "delivery_fee_billed": 100.0,
            "delivery_cost_actual": 80.0,
            "install_fee_billed": 400.0,
            "discount_rate": 0.0,
            "tax_rate": 20.0,
            "status": "draft",
            "reference": "INV-2024-005",
            "note": "مشروع شقة - في الانتظار",
            "items": [
                {"material": created_materials[6], "pieces": 2.0, "length_m": 2.4, "width_m": 1.6}
            ]
        }
    ]
    
    created_invoices = []
    for invoice_data in invoices_data:
        items_data = invoice_data.pop("items")
        
        # Create invoice
        invoice = Invoice.create(**invoice_data)
        created_invoices.append(invoice)
        
        # Create invoice items and calculate totals
        total_sell_price = 0.0
        total_buy_cost = 0.0
        
        for item_data in items_data:
            material = item_data["material"]
            pieces = item_data["pieces"]
            length_m = item_data.get("length_m", material.length_m)
            width_m = item_data.get("width_m", material.width_m)
            
            # Calculate area
            if "area_override" in item_data:
                area = item_data["area_override"]
            else:
                area = area_m2(length_m, width_m, pieces)
            
            # Create invoice item
            InvoiceItem.create(
                invoice=invoice,
                material=material,
                pieces=pieces,
                length_m=length_m,
                width_m=width_m,
                thickness_mm=material.thickness_mm,
                area_m2=area,
                buy_price_m2=material.buy_price_m2,
                sell_price_m2=material.sell_price_m2
            )
            
            total_sell_price += area * material.sell_price_m2
            total_buy_cost += area * material.buy_price_m2
        
        # Calculate invoice totals
        from core.services.calc import (
            pre_discount_total, discount, taxable_base, 
            tax_amount, final_total, profit_margin
        )
        
        subtotal = pre_discount_total(
            total_sell_price, 
            invoice.delivery_fee_billed, 
            invoice.install_fee_billed
        )
        
        discount_amount = discount(subtotal, invoice.discount_rate)
        taxable_base_amount = taxable_base(subtotal, discount_amount)
        tax_amount_val = tax_amount(taxable_base_amount, invoice.tax_rate)
        total = final_total(taxable_base_amount, tax_amount_val)
        
        profit_margin_val = profit_margin(
            total_sell_price,
            invoice.delivery_fee_billed,
            invoice.install_fee_billed,
            total_buy_cost,
            invoice.delivery_cost_actual
        )
        
        # Update invoice with calculated values
        invoice.subtotal = subtotal
        invoice.tax_amount = tax_amount_val
        invoice.total = total
        invoice.profit_margin = profit_margin_val
        invoice.save()
        
        print(f"Created invoice: {invoice.reference} - {invoice.total:.2f} د.م")
    
    # Create stock movements for purchases
    stock_moves_data = [
        {
            "material": created_materials[0],
            "qty_change_m2": 36.0,  # 6 slabs * 6 m2 each
            "note": "شراء جديد من المورد",
            "source": "purchase"
        },
        {
            "material": created_materials[1],
            "qty_change_m2": 15.0,  # 4 slabs * 3.75 m2 each
            "note": "شراء جديد من المورد",
            "source": "purchase"
        },
        {
            "material": created_materials[4],
            "qty_change_m2": 50.0,
            "note": "شراء بالمتر المربع",
            "source": "purchase"
        }
    ]
    
    for move_data in stock_moves_data:
        StockMove.create(**move_data)
        print(f"Created stock move: {move_data['material'].name} +{move_data['qty_change_m2']} م²")
    
    db.close()
    print("\nTest data creation completed successfully!")
    print(f"Created:")
    print(f"- {len(created_materials)} materials")
    print(f"- {len(created_clients)} clients")
    print(f"- {len(created_workers)} workers")
    print(f"- {len(created_invoices)} invoices")
    print(f"- {len(expenses_data)} expenses")
    print(f"- 56 attendance records (4 workers × 14 days)")
    print(f"- {len(stock_moves_data)} stock movements")

if __name__ == "__main__":
    create_test_data()

