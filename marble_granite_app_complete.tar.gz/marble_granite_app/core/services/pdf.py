from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_LEFT, TA_CENTER
from reportlab.lib.colors import black, colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.units import inch
from core.rtl import get_rtl_text
from core.i18n import format_currency
import os

# Register Arabic fonts
font_path_amiri = os.path.join(os.path.dirname(__file__), "..", "assets", "fonts", "Amiri-Regular.ttf")
font_path_cairo = os.path.join(os.path.dirname(__file__), "..", "assets", "fonts", "Cairo-Regular.ttf")

try:
    pdfmetrics.registerFont(TTFont(\'Amiri\', font_path_amiri))
    pdfmetrics.registerFont(TTFont(\'Cairo\', font_path_cairo))
except Exception as e:
    print(f"Error loading fonts: {e}. Please ensure Amiri-Regular.ttf and Cairo-Regular.ttf are in assets/fonts/")

def generate_invoice_pdf(invoice, output_path):
    doc = SimpleDocTemplate(output_path, pagesize=A4)
    styles = getSampleStyleSheet()

    # Custom style for RTL text
    styles.add(ParagraphStyle(name=\'RTL\', fontName=\'Amiri\', fontSize=12, alignment=TA_RIGHT, leading=14))
   styles.add(ParagraphStyle(name=\'RTL_Heading\', fontName=\'Amiri\', fontSize=16, alignment=TA_RIGHT, leading=18))
    styles.add(ParagraphStyle(name=\'RTL_Table_Header\', fontName=\'Amiri\', fontSize=10, alignment=TA_RIGHT, leading=12))
    styles.add(ParagraphStyle(name=\'RTL_Table_Cell\', fontName=\'Amiri\', fontSize=10, alignment=TA_RIGHT, leading=12))





    story = []

    # Company Info (Placeholder)
    story.append(Paragraph(get_rtl_text("شركة الرخام والجرانيت"), styles["RTL_Heading"]))
    story.append(Paragraph(get_rtl_text("العنوان: 123 شارع الأمل، الدار البيضاء"), styles["RTL"]))
    story.append(Paragraph(get_rtl_text("الهاتف: +212 600 000000"), styles["RTL"]))
    story.append(Spacer(1, 0.2 * inch))

    # Invoice Header
    story.append(Paragraph(get_rtl_text(f"فاتورة رقم: {invoice.reference or invoice.id}"), styles["RTL"]))
    story.append(Paragraph(get_rtl_text(f"التاريخ: {invoice.date.strftime(\"%Y-%m-%d\")}"), styles["RTL"]))
    story.append(Spacer(1, 0.2 * inch))

    # Client Info
    story.append(Paragraph(get_rtl_text("بيانات العميل:"), styles["RTL"]))
    story.append(Paragraph(get_rtl_text(f"الاسم: {invoice.client.name}"), styles["RTL"]))
    story.append(Paragraph(get_rtl_text(f"الهاتف: {invoice.client.phone or \"لا يوجد\"}"), styles["RTL"]))
    story.append(Paragraph(get_rtl_text(f"العنوان: {invoice.client.address or \"لا يوجد\"}"), styles["RTL"]))
    story.append(Spacer(1, 0.4 * inch))




    # Invoice Items Table
    data = [
        [Paragraph(get_rtl_text("الإجمالي"), styles["RTL_Table_Header"]), 
         Paragraph(get_rtl_text("سعر الوحدة (د.م/م²)"), styles["RTL_Table_Header"]), 
         Paragraph(get_rtl_text("المساحة (م²)"), styles["RTL_Table_Header"]), 
         Paragraph(get_rtl_text("الكمية"), styles["RTL_Table_Header"]), 
         Paragraph(get_rtl_text("النوع"), styles["RTL_Table_Header"]), 
         Paragraph(get_rtl_text("المادة"), styles["RTL_Table_Header"])]
    
    for item in invoice.items:
        data.append([
            Paragraph(get_rtl_text(format_currency(item.area_m2 * item.sell_price_m2)), styles["RTL_Table_Cell"]),
            Paragraph(get_rtl_text(format_currency(item.sell_price_m2)), styles["RTL_Table_Cell"]),
            Paragraph(get_rtl_text(str(item.area_m2)), styles["RTL_Table_Cell"]),
            Paragraph(get_rtl_text(str(item.pieces)), styles["RTL_Table_Cell"]),
            Paragraph(get_rtl_text(item.material.type), styles["RTL_Table_Cell"]),
            Paragraph(get_rtl_text(item.material.name), styles["RTL_Table_Cell"])
        ])

    table = Table(data, colWidths=[1.2*inch, 1.2*inch, 1.2*inch, 0.8*inch, 1.2*inch, 1.5*inch])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("FONTNAME", (0, 0), (-1, 0), "Amiri"),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
        ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
        ("GRID", (0, 0), (-1, -1), 1, colors.black),
        ("BOX", (0, 0), (-1, -1), 1, colors.black),
    ]))
    story.append(table)
    story.append(Spacer(1, 0.4 * inch))




    # Summary
    story.append(Paragraph(get_rtl_text(f"الإجمالي قبل الخصم: {format_currency(invoice.subtotal)}"), styles["RTL"]))
    story.append(Paragraph(get_rtl_text(f"الخصم ({invoice.discount_rate}%): {format_currency(invoice.subtotal - invoice.taxable_base)}"), styles["RTL"]))
    story.append(Paragraph(get_rtl_text(f"الأساس الخاضع للضريبة: {format_currency(invoice.taxable_base)}"), styles["RTL"]))
    story.append(Paragraph(get_rtl_text(f"الضريبة ({invoice.tax_rate}%): {format_currency(invoice.tax_amount)}"), styles["RTL"]))
    story.append(Paragraph(get_rtl_text(f"الإجمالي النهائي: {format_currency(invoice.total)}"), styles["RTL_Heading"]))
    story.append(Spacer(1, 0.4 * inch))

    # Notes
    if invoice.note:
        story.append(Paragraph(get_rtl_text("ملاحظات:"), styles["RTL"]))
        story.append(Paragraph(get_rtl_text(invoice.note), styles["RTL"]))

    doc.build(story)


