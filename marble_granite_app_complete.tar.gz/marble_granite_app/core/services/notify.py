try:
    from plyer import notification
    PLYER_AVAILABLE = True
except ImportError:
    PLYER_AVAILABLE = False
    print("Plyer not available. Notifications will be disabled.")

from core.models.inventory import Material

class NotificationService:
    def __init__(self):
        self.enabled = PLYER_AVAILABLE
    
    def show_notification(self, title, message, timeout=5):
        """Show a system notification."""
        if not self.enabled:
            print(f"Notification: {title} - {message}")
            return
        
        try:
            notification.notify(
                title=title,
                message=message,
                timeout=timeout,
                app_name="إدارة الرخام والجرانيت"
            )
        except Exception as e:
            print(f"Error showing notification: {e}")
    
    def check_low_stock(self):
        """Check for materials with low stock and send notifications."""
        try:
            low_stock_materials = Material.select().where(
                Material.qty_value <= Material.low_stock_threshold,
                Material.is_deleted == False
            )
            
            for material in low_stock_materials:
                self.show_notification(
                    title="تنبيه: انخفاض المخزون",
                    message=f"المادة '{material.name}' وصلت إلى الحد الأدنى للمخزون ({material.qty_value} {material.qty_unit})",
                    timeout=10
                )
            
            return len(low_stock_materials)
            
        except Exception as e:
            print(f"Error checking low stock: {e}")
            return 0
    
    def notify_invoice_created(self, invoice_id, client_name, total):
        """Notify when a new invoice is created."""
        self.show_notification(
            title="فاتورة جديدة",
            message=f"تم إنشاء فاتورة جديدة للعميل {client_name} بمبلغ {total}",
            timeout=5
        )
    
    def notify_sync_completed(self, success, message):
        """Notify when synchronization is completed."""
        title = "تمت المزامنة" if success else "فشلت المزامنة"
        self.show_notification(
            title=title,
            message=message,
            timeout=5
        )
    
    def notify_backup_completed(self, success, message):
        """Notify when backup is completed."""
        title = "تم النسخ الاحتياطي" if success else "فشل النسخ الاحتياطي"
        self.show_notification(
            title=title,
            message=message,
            timeout=5
        )

# Global notification service instance
notification_service = NotificationService()

