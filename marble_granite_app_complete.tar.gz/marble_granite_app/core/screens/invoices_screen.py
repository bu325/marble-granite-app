from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.toolbar import MDTopAppBar
from kivymd.uix.textfield import MDTextField
from kivymd.uix.list import MDList, ThreeLineListItem
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.card import MDCard
from core.models.invoices import Invoice

class InvoicesScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = "invoices"
        
        # Main layout
        main_layout = MDBoxLayout(orientation="vertical")
        
        # Top app bar
        toolbar = MDTopAppBar(
            title="الفواتير",
            left_action_items=[["arrow-right", lambda x: self.go_back()]],
            right_action_items=[["plus", lambda x: self.create_invoice()]],
            elevation=2
        )
        main_layout.add_widget(toolbar)
        
        # Filter buttons
        filter_layout = MDBoxLayout(
            size_hint_y=None,
            height="60dp",
            padding="10dp",
            spacing="10dp"
        )
        
        all_btn = MDRaisedButton(
            text="الكل",
            size_hint_x=0.25,
            on_release=lambda x: self.filter_invoices("all")
        )
        filter_layout.add_widget(all_btn)
        
        draft_btn = MDRaisedButton(
            text="مسودة",
            size_hint_x=0.25,
            on_release=lambda x: self.filter_invoices("draft")
        )
        filter_layout.add_widget(draft_btn)
        
        posted_btn = MDRaisedButton(
            text="مرسلة",
            size_hint_x=0.25,
            on_release=lambda x: self.filter_invoices("posted")
        )
        filter_layout.add_widget(posted_btn)
        
        search_btn = MDIconButton(
            icon="magnify",
            on_release=self.search_invoices
        )
        filter_layout.add_widget(search_btn)
        
        main_layout.add_widget(filter_layout)
        
        # Invoices list
        self.invoices_scroll = MDScrollView()
        self.invoices_list = MDList()
        self.invoices_scroll.add_widget(self.invoices_list)
        main_layout.add_widget(self.invoices_scroll)
        
        self.add_widget(main_layout)
        self.load_invoices()
    
    def go_back(self):
        # TODO: Navigate back to main screen
        pass
    
    def create_invoice(self):
        # TODO: Open create invoice screen
        pass
    
    def filter_invoices(self, filter_type):
        # TODO: Filter invoices by status
        pass
    
    def search_invoices(self, instance):
        # TODO: Implement search functionality
        pass
    
    def load_invoices(self):
        # TODO: Load invoices from database
        # For now, add some dummy data
        self.invoices_list.clear_widgets()
        
        # Dummy invoices
        invoices = [
            {"id": "INV-001", "client": "أحمد محمد", "date": "2024-01-15", "total": "1,250.00 د.م", "status": "مرسلة"},
            {"id": "INV-002", "client": "فاطمة الزهراء", "date": "2024-01-16", "total": "890.50 د.م", "status": "مسودة"},
            {"id": "INV-003", "client": "يوسف العلوي", "date": "2024-01-17", "total": "2,100.00 د.م", "status": "مرسلة"}
        ]
        
        for invoice in invoices:
            item = ThreeLineListItem(
                text=f"فاتورة {invoice['id']}",
                secondary_text=f"العميل: {invoice['client']} | التاريخ: {invoice['date']}",
                tertiary_text=f"المبلغ: {invoice['total']} | الحالة: {invoice['status']}",
                on_release=lambda x, inv=invoice: self.view_invoice(inv)
            )
            self.invoices_list.add_widget(item)
    
    def view_invoice(self, invoice):
        # TODO: Open invoice details screen
        pass

