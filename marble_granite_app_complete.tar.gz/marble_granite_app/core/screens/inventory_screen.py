from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.toolbar import MDTopAppBar
from kivymd.uix.textfield import MDTextField
from kivymd.uix.list import MDList, ThreeLineListItem
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from core.models.inventory import Material

class InventoryScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = "inventory"
        
        # Main layout
        main_layout = MDBoxLayout(orientation="vertical")
        
        # Top app bar
        toolbar = MDTopAppBar(
            title="إدارة المخزون",
            left_action_items=[["arrow-right", lambda x: self.go_back()]],
            right_action_items=[["plus", lambda x: self.add_material()]],
            elevation=2
        )
        main_layout.add_widget(toolbar)
        
        # Search field
        search_layout = MDBoxLayout(
            size_hint_y=None,
            height="60dp",
            padding="10dp"
        )
        
        self.search_field = MDTextField(
            hint_text="البحث في المواد...",
            size_hint_x=0.8
        )
        search_layout.add_widget(self.search_field)
        
        search_btn = MDIconButton(
            icon="magnify",
            on_release=self.search_materials
        )
        search_layout.add_widget(search_btn)
        
        main_layout.add_widget(search_layout)
        
        # Materials list
        self.materials_scroll = MDScrollView()
        self.materials_list = MDList()
        self.materials_scroll.add_widget(self.materials_list)
        main_layout.add_widget(self.materials_scroll)
        
        self.add_widget(main_layout)
        self.load_materials()
    
    def go_back(self):
        # TODO: Navigate back to main screen
        pass
    
    def add_material(self):
        # TODO: Open add material dialog
        pass
    
    def search_materials(self, instance):
        # TODO: Implement search functionality
        pass
    
    def load_materials(self):
        # TODO: Load materials from database
        # For now, add some dummy data
        self.materials_list.clear_widgets()
        
        # Dummy materials
        materials = [
            {"name": "رخام كرارة أبيض", "type": "رخام", "qty": "15.5 م²", "price": "250.00 د.م/م²"},
            {"name": "جرانيت أسود", "type": "جرانيت", "qty": "8.2 م²", "price": "180.00 د.م/م²"},
            {"name": "رخام أخضر", "type": "رخام", "qty": "22.0 م²", "price": "300.00 د.م/م²"}
        ]
        
        for material in materials:
            item = ThreeLineListItem(
                text=material["name"],
                secondary_text=f"النوع: {material['type']} | الكمية: {material['qty']}",
                tertiary_text=f"السعر: {material['price']}",
                on_release=lambda x, mat=material: self.edit_material(mat)
            )
            self.materials_list.add_widget(item)
    
    def edit_material(self, material):
        # TODO: Open edit material dialog
        pass

