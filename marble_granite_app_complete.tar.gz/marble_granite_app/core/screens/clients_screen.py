from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.toolbar import MDTopAppBar
from kivymd.uix.textfield import MDTextField
from kivymd.uix.list import MDList, TwoLineListItem
from kivymd.uix.scrollview import MDScrollView
from core.models.clients import Client

class ClientsScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = "clients"
        
        # Main layout
        main_layout = MDBoxLayout(orientation="vertical")
        
        # Top app bar
        toolbar = MDTopAppBar(
            title="إدارة العملاء",
            left_action_items=[["arrow-right", lambda x: self.go_back()]],
            right_action_items=[["plus", lambda x: self.add_client()]],
            elevation=2
        )
        main_layout.add_widget(toolbar)
        
        # Search field
        search_layout = MDBoxLayout(
            size_hint_y=None,
            height="60dp",
            padding="10dp"
        )
        
        self.search_field = MDTextField(
            hint_text="البحث في العملاء...",
            size_hint_x=0.8
        )
        search_layout.add_widget(self.search_field)
        
        search_btn = MDIconButton(
            icon="magnify",
            on_release=self.search_clients
        )
        search_layout.add_widget(search_btn)
        
        main_layout.add_widget(search_layout)
        
        # Clients list
        self.clients_scroll = MDScrollView()
        self.clients_list = MDList()
        self.clients_scroll.add_widget(self.clients_list)
        main_layout.add_widget(self.clients_scroll)
        
        self.add_widget(main_layout)
        self.load_clients()
    
    def go_back(self):
        # TODO: Navigate back to main screen
        pass
    
    def add_client(self):
        # TODO: Open add client dialog
        pass
    
    def search_clients(self, instance):
        # TODO: Implement search functionality
        pass
    
    def load_clients(self):
        # TODO: Load clients from database
        # For now, add some dummy data
        self.clients_list.clear_widgets()
        
        # Dummy clients
        clients = [
            {"name": "أحمد محمد", "phone": "+212 600 123456", "address": "الدار البيضاء"},
            {"name": "فاطمة الزهراء", "phone": "+212 661 789012", "address": "الرباط"},
            {"name": "يوسف العلوي", "phone": "+212 650 345678", "address": "فاس"}
        ]
        
        for client in clients:
            item = TwoLineListItem(
                text=client["name"],
                secondary_text=f"الهاتف: {client['phone']} | العنوان: {client['address']}",
                on_release=lambda x, cli=client: self.edit_client(cli)
            )
            self.clients_list.add_widget(item)
    
    def edit_client(self, client):
        # TODO: Open edit client dialog
        pass

