from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.label import MDLabel
from kivymd.uix.toolbar import MDTopAppBar
from kivymd.uix.navigationdrawer import MDNavigationDrawer, MDNavigationDrawerMenu
from kivymd.uix.list import MDList, OneLineListItem
from kivy.uix.screenmanager import ScreenManager, Screen

class MainScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = "main"
        
        # Main layout
        main_layout = MDBoxLayout(orientation="vertical")
        
        # Top app bar
        toolbar = MDTopAppBar(
            title="إدارة الرخام والجرانيت",
            left_action_items=[["menu", lambda x: self.nav_drawer_open()]],
            elevation=2
        )
        main_layout.add_widget(toolbar)
        
        # Content area
        content_layout = MDBoxLayout(
            orientation="vertical",
            padding="20dp",
            spacing="20dp"
        )
        
        # Welcome label
        welcome_label = MDLabel(
            text="مرحباً بك في تطبيق إدارة الرخام والجرانيت",
            theme_text_color="Primary",
            size_hint_y=None,
            height="40dp",
            halign="center"
        )
        content_layout.add_widget(welcome_label)
        
        # Quick action buttons
        buttons_layout = MDBoxLayout(
            orientation="vertical",
            spacing="10dp",
            size_hint_y=None,
            height="300dp"
        )
        
        # Inventory button
        inventory_btn = MDRaisedButton(
            text="إدارة المخزون",
            size_hint_y=None,
            height="50dp",
            on_release=self.go_to_inventory
        )
        buttons_layout.add_widget(inventory_btn)
        
        # Clients button
        clients_btn = MDRaisedButton(
            text="إدارة العملاء",
            size_hint_y=None,
            height="50dp",
            on_release=self.go_to_clients
        )
        buttons_layout.add_widget(clients_btn)
        
        # Workers button
        workers_btn = MDRaisedButton(
            text="إدارة العمال",
            size_hint_y=None,
            height="50dp",
            on_release=self.go_to_workers
        )
        buttons_layout.add_widget(workers_btn)
        
        # Invoices button
        invoices_btn = MDRaisedButton(
            text="الفواتير",
            size_hint_y=None,
            height="50dp",
            on_release=self.go_to_invoices
        )
        buttons_layout.add_widget(invoices_btn)
        
        # Reports button
        reports_btn = MDRaisedButton(
            text="التقارير",
            size_hint_y=None,
            height="50dp",
            on_release=self.go_to_reports
        )
        buttons_layout.add_widget(reports_btn)
        
        content_layout.add_widget(buttons_layout)
        main_layout.add_widget(content_layout)
        
        self.add_widget(main_layout)
    
    def nav_drawer_open(self):
        # TODO: Implement navigation drawer
        pass
    
    def go_to_inventory(self, instance):
        # TODO: Navigate to inventory screen
        pass
    
    def go_to_clients(self, instance):
        # TODO: Navigate to clients screen
        pass
    
    def go_to_workers(self, instance):
        # TODO: Navigate to workers screen
        pass
    
    def go_to_invoices(self, instance):
        # TODO: Navigate to invoices screen
        pass
    
    def go_to_reports(self, instance):
        # TODO: Navigate to reports screen
        pass

