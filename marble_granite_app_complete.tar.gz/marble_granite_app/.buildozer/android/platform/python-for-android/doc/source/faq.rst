FAQ
===

python-for-android has an `online FAQ <https://github.com/kivy/python-for-android/blob/master/FAQ.md>`_. It contains
the answers to questions that repeatedly come up.
